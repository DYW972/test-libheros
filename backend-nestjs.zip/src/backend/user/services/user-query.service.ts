import { Injectable } from '@nestjs/common';

import { User } from '../user.entity';
import { FindUsersUseCase, GetUserByEmail, GetUserById } from 'user/use-cases';

@Injectable()
export class UserQueryService {
  constructor(
    private readonly findUsersUseCase: FindUsersUseCase,
    private readonly getUserById: GetUserById,
    private readonly getUserByEmail: GetUserByEmail,
  ) {}

  async findAll(): Promise<User[]> {
    return await this.findUsersUseCase.execute();
  }

  async findOneById(id: string): Promise<User[]> {
    return await this.getUserById.execute(id);
  }

  async findByEmail(email: string): Promise<User[]> {
    return await this.getUserByEmail.execute(email);
  }
}
