import { Injectable } from '@nestjs/common';

import { User } from '../user.entity';
import { UpdateUserUseCase, DeleteUserUseCase } from 'user/use-cases';
import { UpdateUserInput } from 'user/user.schema';

@Injectable()
export class UserCommandService {
  constructor(
    private readonly updateUserUseCase: UpdateUserUseCase,
    private readonly deleteUserUseCase: DeleteUserUseCase,
  ) {}

  async update(id: string, values: UpdateUserInput): Promise<User> {
    return await this.updateUserUseCase.execute(id, values);
  }

  async delete(id: string): Promise<void> {
    return await this.deleteUserUseCase.execute(id);
  }
}
