import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { User } from './user.entity';
import {
  AdminController,
  UserCommandController,
  UserQueryController,
} from './controllers';
import { UserCommandService, UserQueryService } from './services';
import {
  DeleteUserUseCase,
  FindUsersUseCase,
  GetUserByEmail,
  GetUserById,
  UpdateUserUseCase,
} from './use-cases';

import { RoleModule } from 'role/role.module';

@Module({
  imports: [TypeOrmModule.forFeature([User]), RoleModule],
  controllers: [AdminController, UserCommandController, UserQueryController],
  providers: [
    UserCommandService,
    UserQueryService,
    DeleteUserUseCase,
    FindUsersUseCase,
    GetUserByEmail,
    GetUserById,
    UpdateUserUseCase,
  ],
  exports: [
    UserCommandService,
    UserQueryService,
    DeleteUserUseCase,
    FindUsersUseCase,
    GetUserByEmail,
    GetUserById,
    UpdateUserUseCase,
  ],
})
export class UserModule {}
