import { z } from 'zod';
import { UserRoleEnum } from 'common';

export const BaseUserSchema = z.object({
  role: UserRoleEnum.optional(),
  name: z.string().min(1).optional(),
  email: z.string().email().optional(),
  password: z.string().min(6).optional(),
});

export const CreateUserSchema = BaseUserSchema.extend({
  role: BaseUserSchema.shape.role.default(UserRoleEnum.Enum.user),
  name: BaseUserSchema.shape.name,
  email: BaseUserSchema.shape.email,
  password: BaseUserSchema.shape.password,
});

export const UpdateUserSchema = BaseUserSchema.partial();

export type CreateUserInput = z.infer<typeof CreateUserSchema>;
export type UpdateUserInput = z.infer<typeof UpdateUserSchema>;
