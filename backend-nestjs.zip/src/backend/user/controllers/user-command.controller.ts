import { Body, Controller, Delete, Param, Patch } from '@nestjs/common';
import { ValidationPipe } from 'common';
import { UserCommandService } from 'user/services';
import { User } from 'user/user.entity';
import { UpdateUserInput, UpdateUserSchema } from 'user/user.schema';

@Controller('users')
export class UserCommandController {
  constructor(private readonly service: UserCommandService) {}

  @Patch()
  update(
    @Param('id') id: string,
    @Body(new ValidationPipe(UpdateUserSchema))
    body: UpdateUserInput,
  ): Promise<User> {
    return this.service.update(id, body);
  }

  @Delete()
  delete(@Param('id') id: string): Promise<void> {
    return this.service.delete(id);
  }
}
