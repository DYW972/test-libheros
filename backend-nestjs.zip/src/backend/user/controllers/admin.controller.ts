import { Controller, Get, UseGuards } from '@nestjs/common';
import { Can } from 'common';
import { PoliciesGuard } from 'common';
import { JwtAuthGuard } from 'common/guards/jwt.guard';

@Controller('admin')
@UseGuards(JwtAuthGuard, PoliciesGuard)
export class AdminController {
  @Can('admin-only')
  @Get('admin-data')
  getAdminData() {
    return 'Only admin can see this';
  }
}
