import { Controller, Get, Param } from '@nestjs/common';
import { UserQueryService } from 'user/services';

@Controller('users')
export class UserQueryController {
  constructor(private readonly service: UserQueryService) {}

  @Get()
  find() {
    return this.service.findAll();
  }

  @Get('id/:id')
  findOneById(@Param('id') id: string) {
    return this.service.findOneById(id);
  }

  @Get('email/:email')
  findOneByEmail(@Param('email') email: string) {
    return this.service.findByEmail(email);
  }
}
