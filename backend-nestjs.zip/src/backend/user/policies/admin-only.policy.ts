import { ExecutionContext } from '@nestjs/common';
import { User } from 'user/user.entity';
import { PolicyHandler } from 'common/interfaces/policy-handler.interface';

export class AdminOnlyPolicy implements PolicyHandler {
  handle(user: User, _context: ExecutionContext): boolean {
    return user.role?.name === 'admin';
  }
}
