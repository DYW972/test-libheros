import { Injectable, NotFoundException } from '@nestjs/common';
import { UserTemplateUseCase } from './user-template.usecase';
import { User } from 'user/user.entity';

@Injectable()
export class GetUserByEmail extends UserTemplateUseCase {
  async execute(email: string): Promise<User[]> {
    const user = await this.repository.findBy({ email });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }
}
