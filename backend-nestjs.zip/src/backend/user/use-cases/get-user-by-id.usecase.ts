import { Injectable, NotFoundException } from '@nestjs/common';
import { UserTemplateUseCase } from './user-template.usecase';
import { User } from 'user/user.entity';

@Injectable()
export class GetUserById extends UserTemplateUseCase {
  async execute(id: string): Promise<User[]> {
    const user = await this.repository.findBy({ id });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }
}
