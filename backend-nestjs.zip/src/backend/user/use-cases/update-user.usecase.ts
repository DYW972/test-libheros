import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { UserTemplateUseCase } from './user-template.usecase';
import { User } from 'user/user.entity';
import { UpdateUserInput } from 'user/user.schema';

@Injectable()
export class UpdateUserUseCase extends UserTemplateUseCase {
  async execute(id: string, values: UpdateUserInput): Promise<User> {
    const existingUser = await this.repository.findOne({
      where: { id },
      relations: ['role'],
    });
    if (!existingUser) {
      throw new NotFoundException(`User not found`);
    }

    if (values.role === undefined) {
      throw new BadRequestException(`Invalid credentials`);
    }

    const update = Object.assign(existingUser, {
      ...(values.name !== undefined && { name: values.name }),
      ...(values.email !== undefined && { email: values.email }),
      ...(values.password !== undefined && { password: values.password }),
      ...(values.role !== undefined && { role: values.role }),
    });

    const updateUser = await this.repository.save(update);

    return updateUser;
  }
}
