import { Injectable, NotFoundException } from '@nestjs/common';
import { UserTemplateUseCase } from './user-template.usecase';

@Injectable()
export class DeleteUserUseCase extends UserTemplateUseCase {
  async execute(id: string): Promise<void> {
    const result = await this.repository.delete(id);

    if (result.affected === 0) {
      throw new NotFoundException('User not found');
    }
  }
}
