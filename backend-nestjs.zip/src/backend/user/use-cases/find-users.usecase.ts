import { Injectable } from '@nestjs/common';
import { UserTemplateUseCase } from './user-template.usecase';
import { User } from 'user/user.entity';

@Injectable()
export class FindUsersUseCase extends UserTemplateUseCase {
  async execute(): Promise<User[]> {
    return await this.repository.find();
  }
}
