import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserRoleEnum, parseEnumValue, TUserRoleEnum } from 'common';
import { Repository } from 'typeorm';
import { User } from 'user/user.entity';

@Injectable()
export abstract class UserTemplateUseCase {
  constructor(
    @InjectRepository(User)
    protected readonly repository: Repository<User>,
  ) {}
  /**
   * Safely converts a string to a valid RoleStatus value.
   * Throws an error if the string does not match any enum value.
   *
   * @param value - The input string (case-insensitive)
   * @returns A valid TaskStatusEnum
   */
  convertStringToRoleStatusEnum(
    value: string | undefined,
  ): TUserRoleEnum | undefined {
    return parseEnumValue(UserRoleEnum, value);
  }
}
