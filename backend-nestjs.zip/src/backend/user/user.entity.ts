import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  OneToMany,
  ManyToOne,
  UpdateDateColumn,
  JoinColumn,
} from 'typeorm';

import { Role } from 'role/role.entity';
import { Task } from '../task/task.entity';
import { TaskList } from '../task-list/task-list.entity';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Role, (role) => role.users, { nullable: false, eager: true })
  @JoinColumn({ name: 'roleId' })
  role: Role;

  @Column()
  name: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @OneToMany(() => TaskList, (taskList) => taskList.user)
  taskLists: TaskList[];

  @OneToMany(() => Task, (task) => task.user)
  tasks: Task[];

  get roleName(): string {
    return this.role?.name;
  }
}
