import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';

import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';

import { User } from '../user/user.entity';
import { Task } from '../task/task.entity';
import { Role } from '../role/role.entity';
import { TaskList } from '../task-list/task-list.entity';

import { UserModule } from '../user/user.module';
import { TaskModule } from '../task/task.module';
import { RoleModule } from '../role/role.module';
import { AuthModule } from '../authentication/auth.module';
import { TaskListModule } from '../task-list/task-list.module';
import { ThrottlerModule } from '@nestjs/throttler';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: [`.env.demo`, '.env.admin'],
    }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST,
      port: parseInt(process.env.DB_PORT || '5432', 10),
      username: process.env.DB_USERNAME,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      entities: [User, TaskList, Task, Role],
      synchronize: process.env.APP_ENV === 'DEMO',
    }),
    ThrottlerModule.forRoot({
      throttlers: [
        {
          ttl: 60,
          limit: 5,
        },
      ],
    }),
    AuthModule,
    RoleModule,
    UserModule,
    TaskListModule,
    TaskModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
