import { Injectable } from '@nestjs/common';

import {
  GetTaskListByIdUseCase,
  GetUserOwnedTaskListUseCase,
  GetUserOwnedTaskListsUseCase,
} from 'task-list/use-cases';
import { TaskList } from 'task-list/task-list.entity';

@Injectable()
export class TaskListQueryService {
  constructor(
    private readonly getUserOwnedTaskLists: GetUserOwnedTaskListsUseCase,
    private readonly getUserOWnedTaskList: GetUserOwnedTaskListUseCase,
    private readonly getTaskListById: GetTaskListByIdUseCase,
  ) {}

  async findOneById(id: string): Promise<TaskList> {
    return await this.getTaskListById.execute(id);
  }

  async findOneUserOwnedTaskList(
    listId: string,
    userId: string,
  ): Promise<TaskList[]> {
    return await this.getUserOWnedTaskList.execute(listId, userId);
  }

  async findAllUserOwnedTaskLists(id: string): Promise<TaskList[]> {
    return await this.getUserOwnedTaskLists.execute(id);
  }
}
