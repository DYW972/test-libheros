import { Injectable } from '@nestjs/common';

import { TaskList } from '../task-list.entity';
import {
  CreateTaskListUseCase,
  DeleteTaskListUseCase,
  UpdateTaskListUseCase,
} from '../use-cases';
import {
  CreateTaskListInput,
  UpdateTaskListInput,
} from 'task-list/tasks-list.schema';

@Injectable()
export class TaskListCommandService {
  constructor(
    private readonly createTaskListUseCase: CreateTaskListUseCase,
    private readonly updateTaskListUseCase: UpdateTaskListUseCase,
    private readonly deleteTaskListUseCase: DeleteTaskListUseCase,
  ) {}

  async create(data: CreateTaskListInput): Promise<TaskList> {
    return await this.createTaskListUseCase.execute(data);
  }

  async update(id: string, data: UpdateTaskListInput): Promise<TaskList> {
    return await this.updateTaskListUseCase.execute(id, data);
  }

  async delete(id: string) {
    return await this.deleteTaskListUseCase.execute(id);
  }
}
