import { z } from 'zod';
import { TaskListStatusEnum } from 'common';

export const BaseTaskListSchema = z.object({
  name: z.string().min(1),
  status: TaskListStatusEnum.optional().default(TaskListStatusEnum.Enum.open),
});

export const CreateTaskListSchema = BaseTaskListSchema.extend({
  name: BaseTaskListSchema.shape.name,
  status: BaseTaskListSchema.shape.status.default(TaskListStatusEnum.Enum.open),
});

export const UpdateTaskListSchema = BaseTaskListSchema.partial();

export type CreateTaskListInput = z.infer<typeof CreateTaskListSchema>;
export type UpdateTaskListInput = z.infer<typeof UpdateTaskListSchema>;
