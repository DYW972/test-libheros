import { Controller, Get, Param } from '@nestjs/common';
import { User } from 'common';
import { TaskListQueryService } from 'task-list/services';

@Controller('task-lists')
export class TaskListQueryController {
  constructor(private readonly service: TaskListQueryService) {}
  @Get(':id')
  findOneById(@Param('id') id: string) {
    return this.service.findOneById(id);
  }

  @Get('id/:id')
  findOneListUserOwned(@Param('id') id: string, @User('id') userId: string) {
    return this.service.findOneUserOwnedTaskList(id, userId);
  }

  @Get('')
  findAll(@User('id') id: string) {
    return this.service.findAllUserOwnedTaskLists(id);
  }
}
