import { Post, Param, Body, Patch, Delete, Controller } from '@nestjs/common';

import { TaskListCommandService } from '../services';
import { CreateTaskListInput, UpdateTaskListInput } from '../tasks-list.schema';

@Controller('task-lists')
export class TaskListCommandController {
  constructor(private readonly service: TaskListCommandService) {}

  @Post()
  create(@Body() body: CreateTaskListInput) {
    return this.service.create(body);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() body: UpdateTaskListInput) {
    return this.service.update(id, body);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    return this.service.delete(id);
  }
}
