import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { TaskList } from './task-list.entity';
import { TaskListCommandService, TaskListQueryService } from './services';
import {
  TaskListCommandController,
  TaskListQueryController,
} from './controllers';
import {
  CreateTaskListUseCase,
  DeleteTaskListUseCase,
  GetTaskListByIdUseCase,
  GetUserOwnedTaskListUseCase,
  GetUserOwnedTaskListsUseCase,
  UpdateTaskListUseCase,
} from './use-cases';

@Module({
  imports: [TypeOrmModule.forFeature([TaskList])],
  controllers: [TaskListCommandController, TaskListQueryController],
  providers: [
    TaskListQueryService,
    TaskListCommandService,
    CreateTaskListUseCase,
    DeleteTaskListUseCase,
    GetTaskListByIdUseCase,
    GetUserOwnedTaskListUseCase,
    GetUserOwnedTaskListsUseCase,
    UpdateTaskListUseCase,
  ],
  exports: [
    TaskListQueryService,
    TaskListCommandService,
    CreateTaskListUseCase,
    DeleteTaskListUseCase,
    GetTaskListByIdUseCase,
    GetUserOwnedTaskListUseCase,
    GetUserOwnedTaskListsUseCase,
    UpdateTaskListUseCase,
  ],
})
export class TaskListModule {}
