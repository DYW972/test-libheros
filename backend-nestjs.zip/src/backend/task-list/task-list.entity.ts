import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
  ManyToOne,
  JoinColumn,
} from 'typeorm';

import { User } from '../user/user.entity';
import { Task } from '../task/task.entity';
import { TTaskListStatusEnum, TaskListStatusEnum } from 'common';

@Entity('task_lists')
export class TaskList {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({
    type: 'enum',
    enum: TaskListStatusEnum,
    default: TaskListStatusEnum.Enum.open,
  })
  status: TTaskListStatusEnum;

  @ManyToOne(() => User, (user) => user.taskLists, { nullable: false })
  @JoinColumn({ name: 'userId' })
  user: User;

  @OneToMany(() => Task, (task) => task.taskList)
  tasks: Task[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
