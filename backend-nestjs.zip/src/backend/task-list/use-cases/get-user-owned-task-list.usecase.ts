import { Injectable } from '@nestjs/common';
import { TaskListTemplateUseCase } from './task-list-template.usecase';
import { TaskList } from 'task-list/task-list.entity';

@Injectable()
export class GetUserOwnedTaskListUseCase extends TaskListTemplateUseCase {
  async execute(listId: string, userId: string): Promise<TaskList[]> {
    const lists = await this.repository.find({
      where: { id: listId, user: { id: userId } },
      relations: ['tasks'],
    });

    return lists;
  }
}
