import { Injectable, NotFoundException } from '@nestjs/common';
import { TaskListTemplateUseCase } from './task-list-template.usecase';
import { UpdateTaskListInput } from 'task-list/tasks-list.schema';
import { TaskList } from 'task-list/task-list.entity';

@Injectable()
export class UpdateTaskListUseCase extends TaskListTemplateUseCase {
  async execute(id: string, data: UpdateTaskListInput): Promise<TaskList> {
    const result = await this.repository.update(id, {
      ...data,
    });

    if (result.affected === 0) {
      throw new NotFoundException(`Tasks list with id ${id} not found`);
    }

    return await this.repository.findOneBy({ id });
  }
}
