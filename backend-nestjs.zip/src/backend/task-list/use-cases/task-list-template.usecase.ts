import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TaskList } from 'task-list/task-list.entity';
import { Repository } from 'typeorm';
@Injectable()
export class TaskListTemplateUseCase {
  constructor(
    @InjectRepository(TaskList)
    protected readonly repository: Repository<TaskList>,
  ) {}
}
