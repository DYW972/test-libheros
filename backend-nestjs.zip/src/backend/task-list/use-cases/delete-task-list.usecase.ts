import { Injectable, NotFoundException } from '@nestjs/common';
import { TaskListTemplateUseCase } from './task-list-template.usecase';

@Injectable()
export class DeleteTaskListUseCase extends TaskListTemplateUseCase {
  async execute(id: string): Promise<void> {
    const taskListDeleted = await this.repository.delete(id);

    if (taskListDeleted.affected === 0) {
      throw new NotFoundException(`Tasks list with id ${id} not found.`);
    }
  }
}
