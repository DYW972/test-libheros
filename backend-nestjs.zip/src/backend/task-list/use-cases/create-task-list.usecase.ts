import { Injectable } from '@nestjs/common';
import { TaskListTemplateUseCase } from './task-list-template.usecase';
import { CreateTaskListInput } from 'task-list/tasks-list.schema';
import { TaskList } from 'task-list/task-list.entity';

@Injectable()
export class CreateTaskListUseCase extends TaskListTemplateUseCase {
  async execute(data: CreateTaskListInput): Promise<TaskList> {
    const list = this.repository.create(data);
    const savedList = await this.repository.save(list);
    return savedList;
  }
}
