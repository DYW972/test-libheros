import { Injectable } from '@nestjs/common';
import { TaskListTemplateUseCase } from './task-list-template.usecase';
import { TaskList } from 'task-list/task-list.entity';

@Injectable()
export class GetUserOwnedTaskListsUseCase extends TaskListTemplateUseCase {
  async execute(id: string): Promise<TaskList[]> {
    const lists = await this.repository.find({
      where: { user: { id } },
      relations: ['tasks'],
    });
    return lists;
  }
}
