import { Injectable, NotFoundException } from '@nestjs/common';
import { TaskListTemplateUseCase } from './task-list-template.usecase';
import { TaskList } from 'task-list/task-list.entity';

@Injectable()
export class GetTaskListByIdUseCase extends TaskListTemplateUseCase {
  async execute(id: string): Promise<TaskList> {
    const list = await this.repository.findOne({
      where: { id },
      relations: ['tasks'],
    });

    if (!list) {
      throw new NotFoundException(`Tasks list id: ${id} not found`);
    }

    return list;
  }
}
