export interface AuthResponse {
  acces_token: string;
  user: {
    id: string;
    name: string;
  };
}
