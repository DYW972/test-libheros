import { User } from 'user/user.entity';
import { ExecutionContext } from '@nestjs/common';

export interface PolicyHandler {
  handle(user: User, context: ExecutionContext): boolean | Promise<boolean>;
}
