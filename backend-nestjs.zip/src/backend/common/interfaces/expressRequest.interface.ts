// import { Request } from 'express';
// import { Admin } from '../admin/admin.type';

// export interface ExpressRequest extends Request {
//   user: Admin;
// }
