export { CHECK_POLICIES_KEY, Can } from './can.decorator';
export { User } from './user.decorator';
