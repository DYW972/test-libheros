import { Request } from 'express';

export const cookieExtractor = (req: Request): string | null => {
  if (req && req.cookies && typeof req.cookies['access_token'] === 'string') {
    return req.cookies['access_token'];
  }
  return null;
};
