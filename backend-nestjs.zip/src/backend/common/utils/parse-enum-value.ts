import { BadRequestException } from '@nestjs/common';
import { ZodEnum } from 'zod';

/**
 * Converts a string (case-insensitive) to a valid enum value.
 * Throws an error if the string does not match any enum value.
 *
 * @param enumType - The enum to match against
 * @param value - The string to convert
 * @param label - Optional label for error context
 * @returns A valid enum value
 */
export function parseEnumValue<T extends [string, ...string[]]>(
  enumType: ZodEnum<T>,
  value: string | undefined,
  label = 'value',
): T[number] | undefined {
  if (!value) return undefined;

  const entries = Object.entries(enumType) as [string, string][];

  for (const [, enumValue] of entries) {
    if (enumValue.toLowerCase() === value.toLowerCase()) {
      return enumValue as T[number];
    }
  }

  throw new BadRequestException(`Invalid ${label}: "${value}"`);
}
