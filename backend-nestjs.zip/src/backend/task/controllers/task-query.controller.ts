import { User } from 'common';
import { TaskQueryService } from '../services';
import { Get, Param, Controller } from '@nestjs/common';

@Controller('tasks')
export class TaskQueryController {
  constructor(private readonly service: TaskQueryService) {}

  @Get()
  find(@User('id') id: string) {
    return this.service.findAllUserOwnedTasks(id);
  }
  @Get(':id')
  findOneById(@Param('id') id: string, @User('id') userId: string) {
    return this.service.findOneById(id, userId);
  }

  @Get('task-list/:id')
  findOneByTasksListId(@Param('id') id: string, @User('id') userId: string) {
    return this.service.findByTaskListId(id, userId);
  }
}
