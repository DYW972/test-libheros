import { Post, Patch, Delete, Body, Param, Controller } from '@nestjs/common';
import { ValidationPipe } from 'common';
import * as Schema from '../task.schema';
import { TaskCommandService } from '../services';

@Controller('tasks')
export class TaskCommandController {
  constructor(private readonly taskCommandService: TaskCommandService) {}

  @Post()
  create(
    @Body(new ValidationPipe(Schema.CreateTaskSchema))
    body: Schema.CreateTaskInput,
  ) {
    return this.taskCommandService.create(body);
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body(new ValidationPipe(Schema.UpdateTaskSchema))
    body: Schema.UpdateTaskInput,
  ) {
    return this.taskCommandService.update(id, body);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    return this.taskCommandService.delete(id);
  }
}
