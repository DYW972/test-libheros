import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  UpdateDateColumn,
  JoinColumn,
} from 'typeorm';

import { TTaskStatusEnum, TaskStatusEnum } from 'common';
import { User } from '../user/user.entity';
import { TaskList } from '../task-list/task-list.entity';

@Entity('tasks')
export class Task {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  title: string;

  @Column({ type: 'text' })
  description: string;

  @Column({ type: 'timestamp', nullable: true })
  dueDate: Date;

  @Column({
    type: 'enum',
    enum: TaskStatusEnum,
    default: TaskStatusEnum.Values.todo,
  })
  status: TTaskStatusEnum;

  @ManyToOne(() => TaskList, (taskList) => taskList.tasks, { nullable: false })
  @JoinColumn({ name: 'taskListId' })
  taskList: TaskList;

  @ManyToOne(() => User, (user) => user.tasks, { nullable: false })
  @JoinColumn({ name: 'userId' })
  user: User;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
