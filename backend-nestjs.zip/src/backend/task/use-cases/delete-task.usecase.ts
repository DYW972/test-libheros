import { Injectable, NotFoundException } from '@nestjs/common';

import { TaskTemplateUseCase } from './task-template.usecase';

@Injectable()
export class DeleteTaskUseCase extends TaskTemplateUseCase {
  async execute(id: string): Promise<object> {
    const task = await this.repository.findOneBy({ id });
    if (!task) {
      throw new NotFoundException('Task not found');
    }

    const result = await this.repository.delete(id);

    if (result.affected === 0) {
      throw new NotFoundException('Task not found');
    }
    return {
      message: `Task id: ${id} deleted`,
    };
  }
}
