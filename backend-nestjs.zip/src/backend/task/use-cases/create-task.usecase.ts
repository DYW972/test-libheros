import { Injectable } from '@nestjs/common';

import { Task } from '../task.entity';
import { CreateTaskInput } from '../task.schema';
import { TaskTemplateUseCase } from './task-template.usecase';

@Injectable()
export class CreateTaskUseCase extends TaskTemplateUseCase {
  async execute(data: CreateTaskInput): Promise<Task> {
    //TODO: Add find task list by id
    const task = this.repository.create({
      ...data,
      status: this.convertStringToTaskStatusEnum(data.status),
    });
    return this.repository.save(task);
  }
}
