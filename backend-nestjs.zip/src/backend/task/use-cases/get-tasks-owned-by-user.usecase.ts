import { Injectable } from '@nestjs/common';

import { Task } from '../task.entity';
import { TaskTemplateUseCase } from './task-template.usecase';

@Injectable()
export class GetTasksByUserIdUseCase extends TaskTemplateUseCase {
  async execute(userId: string): Promise<Task[]> {
    const task = await this.repository.find({
      where: {
        user: { id: userId },
      },
    });

    return task;
  }
}
