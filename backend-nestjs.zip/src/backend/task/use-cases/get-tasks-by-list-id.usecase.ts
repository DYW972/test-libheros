import { Injectable, NotFoundException } from '@nestjs/common';

import { Task } from '../task.entity';
import { TaskTemplateUseCase } from './task-template.usecase';

@Injectable()
export class GetTasksByTaskListIdUseCase extends TaskTemplateUseCase {
  async execute(taskListId: string, userId?: string): Promise<Task[]> {
    const task = await this.repository.find({
      where: {
        taskList: { id: taskListId },
        ...(userId && { user: { id: userId } }),
      },
    });

    if (!task) {
      throw new NotFoundException(`Task with list ID ${taskListId} not found`);
    }

    return task;
  }
}
