import { Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';

import { parseEnumValue, TaskStatusEnum, TTaskStatusEnum } from 'common';
import { Task } from 'task/task.entity';

@Injectable()
export class TaskTemplateUseCase {
  constructor(
    @InjectRepository(Task)
    protected readonly repository: Repository<Task>,
  ) {}
  /**
   * Safely converts a string to a valid TaskStatusEnum value.
   * Throws an error if the string does not match any enum value.
   *
   * @param value - The input string (case-insensitive)
   * @returns A valid TaskStatusEnum
   */
  protected convertStringToTaskStatusEnum(
    value: string | undefined,
  ): TTaskStatusEnum | undefined {
    return parseEnumValue(TaskStatusEnum, value);
  }
}
