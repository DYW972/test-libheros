import { Injectable, NotFoundException } from '@nestjs/common';

import { Task } from '../task.entity';
import { UpdateTaskInput } from '../task.schema';
import { TaskTemplateUseCase } from './task-template.usecase';

@Injectable()
export class UpdateTaskUseCase extends TaskTemplateUseCase {
  async execute(id: string, data: UpdateTaskInput): Promise<Task> {
    const result = await this.repository.update(id, data);

    if (result.affected === 0) {
      throw new NotFoundException(`Task id ${id} not found`);
    }

    return this.repository.findOneBy({
      id,
    });
  }
}
