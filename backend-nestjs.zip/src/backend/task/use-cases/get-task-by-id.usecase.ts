import { Injectable, NotFoundException } from '@nestjs/common';

import { Task } from '../task.entity';
import { TaskTemplateUseCase } from './task-template.usecase';

@Injectable()
export class GetTaskByIdUseCase extends TaskTemplateUseCase {
  async execute(taskId: string, userId?: string): Promise<Task> {
    const task = await this.repository.findOne({
      where: {
        id: taskId,
        ...(userId && { user: { id: userId } }),
      },
    });

    if (!task) {
      throw new NotFoundException(`Task with ID ${taskId} not found`);
    }

    return task;
  }
}
