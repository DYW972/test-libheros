import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { Task } from './task.entity';

import { TaskCommandService, TaskQueryService } from './services';

import { TaskCommandController, TaskQueryController } from './controllers';
import {
  CreateTaskUseCase,
  DeleteTaskUseCase,
  UpdateTaskUseCase,
  GetTaskByIdUseCase,
  GetTasksByUserIdUseCase,
  GetTasksByTaskListIdUseCase,
} from './use-cases';

@Module({
  imports: [TypeOrmModule.forFeature([Task])],
  controllers: [TaskCommandController, TaskQueryController],
  providers: [
    TaskCommandService,
    TaskQueryService,
    CreateTaskUseCase,
    UpdateTaskUseCase,
    DeleteTaskUseCase,
    GetTaskByIdUseCase,
    GetTasksByTaskListIdUseCase,
    GetTasksByUserIdUseCase,
  ],
  exports: [
    TaskCommandService,
    TaskQueryService,
    CreateTaskUseCase,
    UpdateTaskUseCase,
    DeleteTaskUseCase,
    GetTaskByIdUseCase,
    GetTasksByTaskListIdUseCase,
    GetTasksByUserIdUseCase,
  ],
})
export class TaskModule {}
