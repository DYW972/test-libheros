import { Task } from '../task.entity';
import * as UseCases from 'task/use-cases';
import { Injectable } from '@nestjs/common';

@Injectable()
export class TaskQueryService {
  constructor(
    private readonly getTaskById: UseCases.GetTaskByIdUseCase,
    private readonly getTasksByUserId: UseCases.GetTasksByUserIdUseCase,
    private readonly getTaskByListId: UseCases.GetTasksByTaskListIdUseCase,
  ) {}

  async findOneById(id: string, userId?: string): Promise<Task> {
    return this.getTaskById.execute(id, userId);
  }

  async findByTaskListId(taskListId: string, userId?: string): Promise<Task[]> {
    return this.getTaskByListId.execute(taskListId, userId);
  }

  async findAllUserOwnedTasks(userId: string): Promise<Task[]> {
    return this.getTasksByUserId.execute(userId);
  }
}
