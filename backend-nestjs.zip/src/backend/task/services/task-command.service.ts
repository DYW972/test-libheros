import { Injectable } from '@nestjs/common';

import { Task } from '../task.entity';
import {
  CreateTaskUseCase,
  UpdateTaskUseCase,
  DeleteTaskUseCase,
} from 'task/use-cases';
import { CreateTaskInput, UpdateTaskInput } from '../task.schema';

@Injectable()
export class TaskCommandService {
  constructor(
    private readonly createUseCase: CreateTaskUseCase,
    private readonly updateUseCase: UpdateTaskUseCase,
    private readonly deleteUseCase: DeleteTaskUseCase,
  ) {}

  async create(data: CreateTaskInput): Promise<Task> {
    return this.createUseCase.execute(data);
  }

  async update(id: string, data: UpdateTaskInput): Promise<Task> {
    return this.updateUseCase.execute(id, data);
  }

  async delete(id: string): Promise<object> {
    return await this.deleteUseCase.execute(id);
  }
}
