import { z } from 'zod';
import { TaskStatusEnum } from '../common';

export const BaseTaskSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().max(500).optional(),
  dueDate: z.coerce.date().optional(),
  status: TaskStatusEnum.optional(),
  taskListId: z
    .string()
    .uuid({ message: 'Task list ID must be a valid UUID' })
    .optional(),
  userId: z
    .string()
    .uuid({ message: 'User ID must be a valid UUID' })
    .optional(),
});

/**
 * CreateTaskSchema: For creating new tasks
 * @description All fields required for initial creation.
 */
export const CreateTaskSchema = BaseTaskSchema.extend({
  title: BaseTaskSchema.shape.title,
  status: BaseTaskSchema.shape.status.default('todo'),
});

/**
 * UpdateTaskSchema: For partial updates
 * @description All fields optional (PATCH)
 */
export const UpdateTaskSchema = BaseTaskSchema.partial();

export type CreateTaskInput = z.infer<typeof CreateTaskSchema>;
export type UpdateTaskInput = z.infer<typeof UpdateTaskSchema>;
