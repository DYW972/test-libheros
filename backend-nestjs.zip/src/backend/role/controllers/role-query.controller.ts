import { Controller, Get, Param } from '@nestjs/common';
import * as Services from 'role/services';

@Controller('roles')
export class RoleQueryController {
  constructor(private readonly service: Services.RoleQueryService) {}
  @Get()
  findAll() {
    return this.service.findAll();
  }

  @Get('id/:id')
  findById(@Param('id') id: string) {
    return this.service.findOneById(id);
  }

  @Get('name/:name')
  findByName(@Param('name') name: string) {
    return this.service.findOneByName(name);
  }
}
