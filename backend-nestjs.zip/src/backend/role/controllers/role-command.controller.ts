import { Controller, Post, Param, Body, Delete, Patch } from '@nestjs/common';
import * as Schemas from 'role/role.schema';
import { Role } from 'role/role.entity';

@Controller('roles')
export class RoleCommandController {
  constructor(private readonly service: RoleCommandController) {}

  @Post()
  create(@Body() data: Schemas.CreateRoleInput): Promise<Role> {
    return this.service.create(data);
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() body: Schemas.UpdateRoleInput,
  ): Promise<Role> {
    return this.service.update(id, body);
  }

  @Delete(':id')
  delete(@Param('id') id: string): Promise<Role> {
    return this.service.delete(id);
  }
}
