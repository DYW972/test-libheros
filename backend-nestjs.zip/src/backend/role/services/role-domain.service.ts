import { Injectable } from '@nestjs/common';
import { RoleCommandService, RoleQueryService } from '../services';
import { UserRoleEnum } from 'common';

@Injectable()
export class RoleDomainService {
  constructor(
    private readonly roleQueryService: RoleQueryService,
    private readonly roleCommandService: RoleCommandService,
  ) {}

  async getOrCreateDefaultRole() {
    const defaultRole = UserRoleEnum.Enum.user;
    let role = await this.roleQueryService.findOneByName(defaultRole);
    if (!role) {
      role = await this.roleCommandService.create({ name: defaultRole });
    }
    return role;
  }
}
