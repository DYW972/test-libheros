import { z } from 'zod';
import { UserRoleEnum } from 'common';

export const BaseRoleSchema = z.object({
  name: UserRoleEnum.optional().default(UserRoleEnum.Enum.user),
});

export const CreateRoleSchema = BaseRoleSchema.extend({
  name: BaseRoleSchema.shape.name.default(UserRoleEnum.Enum.user),
});

export const UpdateRoleSchema = BaseRoleSchema.partial();

export type CreateRoleInput = z.infer<typeof CreateRoleSchema>;
export type UpdateRoleInput = z.infer<typeof UpdateRoleSchema>;
