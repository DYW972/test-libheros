import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { Role } from './role.entity';
import { RoleCommandService, RoleQueryService } from './services';
import { RoleCommandController, RoleQueryController } from './controllers';
import {
  CreateRoleUseCase,
  DeleteRoleUseCase,
  GetRoleById,
  GetRoleByName,
  GetRoles,
  UpdateRoleUseCase,
} from './use-cases';

@Module({
  imports: [TypeOrmModule.forFeature([Role])],
  controllers: [RoleCommandController, RoleQueryController],
  providers: [
    RoleCommandService,
    RoleQueryService,
    CreateRoleUseCase,
    DeleteRoleUseCase,
    GetRoleById,
    GetRoleByName,
    GetRoles,
    UpdateRoleUseCase,
  ],
  exports: [
    RoleCommandService,
    RoleQueryService,
    CreateRoleUseCase,
    DeleteRoleUseCase,
    GetRoleById,
    GetRoleByName,
    GetRoles,
    UpdateRoleUseCase,
  ],
})
export class RoleModule {}
