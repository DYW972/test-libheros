import { Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';

import { Role } from 'role/role.entity';

@Injectable()
export class RoleTemplateUseCase {
  constructor(
    @InjectRepository(Role)
    protected readonly repository: Repository<Role>,
  ) {}
}
