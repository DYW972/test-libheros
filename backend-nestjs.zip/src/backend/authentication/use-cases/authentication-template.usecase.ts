import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from 'user/user.entity';
import {
  JwtTokenPayload,
  parseEnumValue,
  TUserRoleEnum,
  UserRoleEnum,
} from 'common';
import { PasswordService, TokenService } from '../services';

@Injectable()
export abstract class AuthenticationTemplateUseCase {
  constructor(
    @InjectRepository(User)
    protected readonly repository: Repository<User>,
    protected readonly passwordService: PasswordService,
    protected readonly tokenService: TokenService,
  ) {}

  protected convertStringToUserRoleEnum(
    value: string | undefined,
  ): TUserRoleEnum | undefined {
    return parseEnumValue(UserRoleEnum, value);
  }

  protected createJwtPayload(
    id: string,
    role: string,
  ): JwtTokenPayload | undefined {
    return {
      sub: id,
      role,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 3600, // expire in 1h
    };
  }
}
