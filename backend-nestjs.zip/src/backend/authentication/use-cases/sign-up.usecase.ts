import { Injectable, ConflictException } from '@nestjs/common';
import { AuthenticationTemplateUseCase } from './authentication-template.usecase';
import { JwtTokenPayload, AuthResponse } from 'common';
import { CreateUserInput } from 'user/user.schema';
import { RoleDomainService } from 'role/services';

@Injectable()
export class SignUpUseCase extends AuthenticationTemplateUseCase {
  constructor(
    private readonly roleDomainService: RoleDomainService,
    ...args: ConstructorParameters<typeof AuthenticationTemplateUseCase>
  ) {
    super(...args);
  }

  async execute(data: CreateUserInput): Promise<AuthResponse> {
    const { email, password } = data;

    await this.ensureEmailNotExists(email);
    const role = await this.roleDomainService.getOrCreateDefaultRole();
    const hashedPassword = await this.passwordService.hash(password);

    const userEntity = this.repository.create({
      ...data,
      password: hashedPassword,
      role,
    });

    const jwtToken: JwtTokenPayload = this.createJwtPayload(
      userEntity.id,
      userEntity.roleName,
    );

    const acces_token = await this.tokenService.generateToken(jwtToken);

    return {
      acces_token,
      user: {
        id: userEntity.id,
        name: userEntity.name,
      },
    };
  }

  private async ensureEmailNotExists(email: string): Promise<void> {
    const existingUser = await this.repository.findOneBy({ email });
    if (existingUser) {
      throw new ConflictException(`Email: ${email} already exists`);
    }
  }
}
