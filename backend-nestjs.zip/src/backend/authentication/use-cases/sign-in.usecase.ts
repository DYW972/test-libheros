import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthenticationTemplateUseCase } from './authentication-template.usecase';
import { JwtTokenPayload } from 'common';
import { CreateUserInput } from 'user/user.schema';
import { User } from 'user/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { PasswordService, TokenService } from 'authentication/services';
import { Repository } from 'typeorm';

@Injectable()
export class SignInUseCase extends AuthenticationTemplateUseCase {
  constructor(
    @InjectRepository(User)
    repository: Repository<User>,
    passwordService: PasswordService,
    tokenService: TokenService,
  ) {
    super(repository, passwordService, tokenService);
  }
  async execute(
    credentials: Pick<CreateUserInput, 'email' | 'password'>,
  ): Promise<string> {
    const { id, roleName } = await this.validateUser(
      credentials.email,
      credentials.password,
    );

    const payload: JwtTokenPayload = this.createJwtPayload(id, roleName);

    return this.tokenService.generateToken(payload);
  }

  private async validateUser(email: string, password: string): Promise<User> {
    const user = await this.repository.findOneBy({ email });
    if (
      !user ||
      !(await this.passwordService.compare(password, user.password))
    ) {
      throw new UnauthorizedException('Invalid credentials');
    }
    return user;
  }
}
