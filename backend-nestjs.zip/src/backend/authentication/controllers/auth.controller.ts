import {
  Controller,
  HttpCode,
  HttpStatus,
  Post,
  Res,
  Body,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { AuthService } from 'authentication/services';
import { CreateUserInput } from 'user/user.schema';

@Controller('auth')
export class AuthController {
  constructor(private service: AuthService) {}

  @Post('signup')
  @HttpCode(HttpStatus.OK)
  async signUp(
    @Body() body: CreateUserInput,
    @Res({ passthrough: true }) res: Response,
  ) {
    const access_token = await this.service.signUp(body);
    res.cookie('access_token', access_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 1000 * 60 * 60 * 24,
    });
  }

  @Post('signin')
  @HttpCode(HttpStatus.OK)
  async signIn(
    @Body() credentials: Pick<CreateUserInput, 'email' | 'password'>,
    @Res({ passthrough: true }) res: Response,
  ) {
    const access_token = await this.service.signIn(credentials);
    res.cookie('access_token', access_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 1000 * 60 * 60 * 24,
    });
  }

  @Post('signout')
  signOut(@Res() res: Response) {
    res.clearCookie('access_token', {
      path: '/',
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
    });
  }

  //   @UseGuards(JwtAuthGuard)
  //   @Get('me')
  //   getProfile(@Req() req: Request & { user: UserDTO }): UserDTO {
  //     return req.user;
  //   }
}
