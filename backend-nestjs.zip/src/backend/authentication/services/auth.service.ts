import { Injectable } from '@nestjs/common';
import { SignInUseCase, SignUpUseCase } from '../use-cases';
import { CreateUserInput } from 'user/user.schema';
import { AuthResponse } from 'common';

@Injectable()
export class AuthService {
  constructor(
    private readonly signInUseCase: SignInUseCase,
    private readonly signUpUseCase: SignUpUseCase,
  ) {}

  async signIn(
    credentials: Pick<CreateUserInput, 'email' | 'password'>,
  ): Promise<string> {
    return await this.signInUseCase.execute(credentials);
  }

  async signUp(data: CreateUserInput): Promise<AuthResponse> {
    return await this.signUpUseCase.execute(data);
  }
}
