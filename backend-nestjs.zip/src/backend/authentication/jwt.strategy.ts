import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { Request } from 'express';

import { UserQueryService } from '../user/services';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private userService: UserQueryService) {
    super({
      jwtFromRequest: ExtractJwt.fromExtractors([
        (request?: Request): string | null => {
          const token: unknown = request.cookies.access_token;
          if (typeof token === 'string') {
            return token;
          }
          return null;
        },
        ExtractJwt.fromAuthHeaderAsBearerToken(),
      ]),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET,
    });
  }

  async validate(payload: {
    id: string;
    email: string;
    name?: string;
  }): Promise<object> {
    const user = await this.userService.findByEmail(payload.email);
    if (!user) {
      throw new UnauthorizedException();
    }

    return {
      id: user[0].id,
      email: user[0].email,
      name: user[0].email,
      role: user[0].roleName,
    };
  }
}
