import { Module } from '@nestjs/common';

import { JwtModule } from '@nestjs/jwt';
import { JwtStrategy } from './jwt.strategy';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { AuthService, PasswordService, TokenService } from './services';
import { AuthController } from './controllers';
import { SignInUseCase, SignUpUseCase } from './use-cases';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../user/user.entity';
import { RoleCommandService, RoleDomainService } from 'role/services';

@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    PassportModule,
    ConfigModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: '1h', algorithm: 'HS512' },
      }),
    }),
  ],
  controllers: [AuthController],
  providers: [
    AuthService,
    PasswordService,
    TokenService,
    JwtStrategy,
    SignInUseCase,
    SignUpUseCase,
    RoleDomainService,
    RoleCommandService,
  ],
  exports: [AuthService],
})
export class AuthModule {}
