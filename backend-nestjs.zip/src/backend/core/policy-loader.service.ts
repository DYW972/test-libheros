import { Injectable, OnModuleInit } from '@nestjs/common';
import { PolicyHandlerRegistry } from 'common/policies/policy-handler.registry';
import { AdminOnlyPolicy } from 'user/policies/admin-only.policy';

@Injectable()
export class PolicyLoaderService implements OnModuleInit {
  constructor(private readonly registry: PolicyHandlerRegistry) {}

  onModuleInit() {
    this.registry.register('admin-only', new AdminOnlyPolicy());
    // register other policies here
  }
}
